<?php
// 引入PHPMailer类
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// 引入 Composer 自动加载文件
require 'vendor/autoload.php';



// 创建PHPMailer对象
$mail = new PHPMailer();
echo 'Message will be sent';
try {

    // 设置SMTP
    $mail->SMTPDebug = 2; 
    $mail->isSMTP();                                         // 使用SMTP
    $mail->Host = 'smtp.gmail.com';                          // 设置SMTP服务器为Gmail
    $mail->SMTPAuth = true;                                  // 启用SMTP认证
    $mail->Username = 'jiguangning2004@gmail.com';           // 填写你的Gmail邮箱地址
    $mail->Password = 'ifzwofrdkfbexvzq';                        // 填写你的Gmail邮箱密码（或者应用专用密码）
    $mail->SMTPSecure = 'ssl';      // 启用SSL加密
    $mail->Port = 465;

    // 生成 selector 和 token
    $selector = bin2hex(random_bytes(8));
    $token    = random_bytes(32);
    // TODO: 将 $selector 及 hash($token) 存入密码重置表，并设置过期时间

    // 发件人信息
    $mail->setFrom('jiguangning2004@gmail.com'); // 发件人邮箱和名称
    $mail->addAddress($_POST['email']);       // 收件人邮箱和名称

    // 邮件内容
    $resetUrl = sprintf(
        'https://www.mmtuts.net/forgottenpwd/create-new-password.php?selector=%s&validator=%s',
        $selector,
        bin2hex($token)
    );
    $mail->isHTML(true);                                      // 设置邮件格式为HTML
    $mail->Subject = 'Reset your password';                   // 邮件主题
    $mail->Body    = 'Click <a href="' . $resetUrl . '">here</a> to reset your password.';
    $mail->AltBody = 'To reset your password, visit the following link: ' . $resetUrl;

    // 发送邮件
    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}


