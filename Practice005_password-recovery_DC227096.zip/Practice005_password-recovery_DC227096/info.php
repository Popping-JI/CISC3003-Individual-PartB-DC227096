<?php
var_dump(extension_loaded('openssl')); // 期望看到 bool(true)
exit;
?>
