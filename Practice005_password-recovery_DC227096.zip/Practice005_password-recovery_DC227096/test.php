<?php
var_dump(extension_loaded('openssl')); // 应该输出 bool(true)
phpinfo();                              // 再看一遍 phpinfo 里有没有 openssl 版本信息
exit;
